# Commands and parameters

These are publication-adapted, anonymized transcriptions and templates. They are not unmodified historical console records. <FUSION_PROJECT> denotes the original FUSION project; <DIAGNOSTIC_ROOT> denotes the 2026-10-16 output collection. Full GWAS, prediction weights and genotype inputs are external and are not bundled.

## Recovered historical analysis commands

The core 353, extended 358 and core 559 launch commands were recovered in user terminal transcriptions. The extended 1,011-model transcription has a missing executable/header line and interleaved output. Independent complete historical stdout/stderr files were not recovered.

### core_353

```powershell
& "<R_3_6_0>/bin/x64/Rscript.exe" "./FUSION.post_process.R" `
--sumstats "./asd.fusion-n.sumstats" `
--input "./ASD.FUSION.17q21.31.GRCh38.core.alltissueFDR005.postprocess.dat" `
--out "./POST_GRCh38/ASD.FUSION.17q21.31.core" `
--ref_ld_chr "./LDREF_GRCh38/1000G.EUR.GRCh38.clean." `
--chr 17 `
--minp_input 1 `
--locus_win 100000 `
--verbose 2
```

### extended_358

```powershell
& "<R_3_6_0>/bin/x64/Rscript.exe" "./FUSION.post_process.R" `
--sumstats "./asd.fusion-n.sumstats" `
--input "./ASD.FUSION.17q21.31.GRCh38.extended.alltissueFDR005.postprocess.dat" `
--out "./POST_GRCh38/ASD.FUSION.17q21.31.extended" `
--ref_ld_chr "./LDREF_GRCh38/1000G.EUR.GRCh38.clean." `
--chr 17 `
--minp_input 1 `
--locus_win 100000 `
--verbose 2
```

### core_559

```powershell
& "<R_3_6_0>/bin/x64/Rscript.exe" `
"./FUSION.post_process.R" `
--sumstats "./asd.fusion-n.sumstats" `
--input "./ASD.FUSION.17q21.31.GRCh38.core.allmodels.postprocess.fixed.dat" `
--out "./POST_GRCh38_ALLMODEL_SENSITIVITY/ASD.FUSION.17q21.31.core.allmodels" `
--ref_ld_chr "./LDREF_GRCh38/1000G.EUR.GRCh38.clean." `
--chr 17 `
--minp_input 1 `
--locus_win 100000 `
--verbose 2
```

### extended_1011 (incomplete historical transcription)

Identifiable fields: FUSION.post_process.R; --sumstats ./asd.fusion-n.sumstats; --input ./ASD.FUSION.17q21.31.GRCh38.extended.allmodels.postprocess.fixed.dat; --out ./POST_GRCh38_ALLMODEL_SENSITIVITY/ASD.FUSION.17q21.31.extended.allmodels; --ref_ld_chr ./LDREF_GRCh38/1000G.EUR.GRCh38.clean.; --chr 17; --minp_input 1; --locus_win 100000; --verbose 2. The missing launcher has not been filled in as a historical fact.

All recovered statistical launches show no --plot, --report or --save_loci flag. No explicit --zthresh, --max_r2, --min_r2 or --max_cz_increase was visible. The local defaults are max_r2=0.90, min_r2=0.05 and max_cz_increase=1.96. The default absolute Z threshold is qnorm(0.05/M/2, lower.tail=FALSE); it is distinct from marginal all-tissue FDR selection.

## Diagnostic executions on 2026-10-16

All eight executions used the instrumented source supplied here and R 3.6.0 with --vanilla. The following normalized template and row-specific substitutions represent the recorded argv. They are provided for traceability, not as new calculations performed during packaging.

```text
<R_3_6_0>/bin/x64/Rscript.exe --vanilla reproducibility/source/FUSION.post_process.instrumented.R \
  --sumstats <FUSION_PROJECT>/asd.fusion-n.sumstats \
  --input <FUSION_PROJECT>/<Input_file> --out <DIAGNOSTIC_ROOT>/<Output_prefix> \
  --ref_ld_chr <FUSION_PROJECT>/LDREF_GRCh38/1000G.EUR.GRCh38.clean. \
  --chr 17 --minp_input 1 --locus_win 100000 --verbose 2 [--zthresh <Explicit_Z>]
```

| Analysis | Mode | Actual absolute Z threshold | Explicit_Z | Input_file | Output_prefix |
| --- | --- | --- | --- | --- | --- |
| core_353 | default | 3.80528140728608 | omitted (default) | ASD.FUSION.17q21.31.GRCh38.core.alltissueFDR005.postprocess.dat | default_core_353/run |
| extended_358 | default | 3.80876112046778 | omitted (default) | ASD.FUSION.17q21.31.GRCh38.extended.alltissueFDR005.postprocess.dat | default_extended_358/run |
| core_559 | default | 3.91757172039658 | omitted (default) | ASD.FUSION.17q21.31.GRCh38.core.allmodels.postprocess.fixed.dat | default_core_559/run |
| extended_1011 | default | 4.05818311062166 | omitted (default) | ASD.FUSION.17q21.31.GRCh38.extended.allmodels.postprocess.fixed.dat | default_extended_1011/run |
| core_353 | fixed | 4.058183 | 4.058183 | ASD.FUSION.17q21.31.GRCh38.core.alltissueFDR005.postprocess.dat | fixed_core_353/run |
| extended_358 | fixed | 4.058183 | 4.058183 | ASD.FUSION.17q21.31.GRCh38.extended.alltissueFDR005.postprocess.dat | fixed_extended_358/run |
| core_559 | fixed | 4.058183 | 4.058183 | ASD.FUSION.17q21.31.GRCh38.core.allmodels.postprocess.fixed.dat | fixed_core_559/run |
| extended_1011 | fixed | 4.058183 | 4.058183 | ASD.FUSION.17q21.31.GRCh38.extended.allmodels.postprocess.fixed.dat | fixed_extended_1011/run |

For default rows, omit --zthresh entirely. In fixed rows Explicit_Z is 4.058183. max_r2=0.90, min_r2=0.05, max_cz_increase=1.96, plot=FALSE, report=FALSE and save_loci=FALSE throughout. Diagnostic_parameters_20261016.tsv supplies every effective option. This combined archive retains the two primary default execution logs and four short default boundary outputs and adds execution.log, run.selection_events.tsv, run.global_instability_guard.tsv and run.joint_included.dat for the default/fixed 559- and 1,011-model diagnostics. See Major2_numerical_stability_notes_EN.md at the archive root; large variance/matrix intermediates are not bundled.

## Environment and external reference identification

FUSION diagnostics: R 3.6.0 (2019-04-26), x86_64-w64-mingw32/x64; plink2R 1.1, optparse 1.7.5, RColorBrewer 1.1-3, Rcpp 1.0.12, RcppEigen 0.3.4.0.0 and getopt 1.20.4. Included sessionInfo files describe the 2026-10-16 diagnostic environment. Historical complete launch transcriptions point to R-3.6.0, but historical dependency snapshots were not recovered. The independent regional helper was run under R 4.4.1; this is not the FUSION diagnostic R version.

Historical LD prefix: LDREF_GRCh38/1000G.EUR.GRCh38.clean.; chr17 BED/BIM/FAM. Processing logs document the EUR subset and clean rsID-labelled reference. External_input_identifiers.tsv identifies inputs by size and SHA256. Prediction_weight_identifiers.tsv identifies the 1,011 unique weight files. The reference contains 489 EUR-labelled individuals and 32,169 unique variants. The independent coordinate comparison used the GRCh38 chr17_hg38_rs_noannot.pvar.zst table linked from https://www.cog-genomics.org/plink/2.0/resources .

The project glist-hg38 gene-track annotation was generated from GENCODE v26 GRCh38 and used by the GRCh38 plotting variant. This annotation adjustment is distinct from the LD/model coordinate validation. The previously recovered core plotting invocation uses FUSION.post_process_GRCh38_plot.R with --plot --plot_legend joint and the same core input, LD prefix, chr17, minp_input=1 and locus_win=100000.
