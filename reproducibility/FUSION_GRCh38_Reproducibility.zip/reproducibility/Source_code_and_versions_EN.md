# Source code and version identification

The first two FUSION scripts are the current local project copies used for the audit. A unique historical FUSION Git commit and an immutable source snapshot from the September analysis could not be recovered. These copies must not be labelled as proven byte-identical historical run-time source. The audit found that default diagnostic global output files matched the archived analysis outputs byte for byte; this does not identify a unique historical source commit.

| Supplied file | SHA256 |
| --- | --- |
| FUSION.post_process.R | 2552c09fd1a78358292843ef9c32b28d2a36cd492c8555acbe9d7890a20d27fd |
| FUSION.post_process_GRCh38_plot.R | fb9b45da4ff464dc5fcaed5a6d8f74754cdb2eaa8003a1598c7864b49a72e603 |
| FUSION.post_process.instrumented.R | 838a3750203290a81ee82fcf00ebe1172ea439f704f365a813a3dc0124addeba |
| fusion_region_coordinate_audit.R | 7d52142e65a6f88c024e7fa24ca3ae15dd20c254344016e78d68e5e431c6c545 |

- FUSION.post_process.R is the existing local post-processing implementation. Upstream project: https://github.com/gusevlab/fusion_twas . The supplied project LICENSE is preserved verbatim.
- FUSION.post_process_GRCh38_plot.R is the existing local plotting variant. It replaces glist-hg19 references with glist-hg38 references; see GRCh38_plot.diff. Historical terminal evidence documents this change and successful core plotting on 2026-09-13. The code is supplied unchanged from the current project file.
- FUSION.post_process.instrumented.R was created on 2026-10-16 for the diagnostic audit. It records effective options, selection stages, boundaries, retention and variances, while retaining the local numerical expressions and selection rules. The supplied instrumentation.diff records changes; its source-path header was anonymized. Added audit-only variance logging can itself emit sqrt(as.numeric(v)) warnings; those are distinct from warnings emitted by the original SNP-conditioning expression.
- fusion_region_coordinate_audit.R is the independent regional reconstruction helper supplied for the audit. It does not compute joint statistics or independently establish a reference build.

The modified variants are identified as such; the original license statement was not edited. No new source-code modification or scientific computation was performed during this packaging task.
