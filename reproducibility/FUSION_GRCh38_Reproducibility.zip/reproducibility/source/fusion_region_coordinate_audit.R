#!/usr/bin/env Rscript
# Read-only independent reconstruction of FUSION post_process regional grouping.
# It does NOT recalculate FUSION conditional statistics or establish a genome build
# by itself. Compare all outputs against the ORIGINAL FUSION run/logs.
#
# Usage:
# Rscript fusion_region_coordinate_audit.R \
#   --input /path/to/core_353.top \
#   --bim /path/to/1000G.EUR.GRCh38.clean.17.bim \
#   --out /path/to/audit_core \
#   --chr 17 --locus-win 100000 --minp-input 1.0
# Optional: --grch38-map /path/to/independently_verified_GRCh38_SNP_CHR_BP.tsv
# The map must have a header with columns SNP, CHR, BP.

args <- commandArgs(trailingOnly=TRUE)
if (length(args) %% 2 != 0) stop("Options must come in --key value pairs.")
opts <- list()
if (length(args)) for (i in seq.int(1, length(args), by=2)) {
  key <- sub('^--', '', args[i])
  if (!startsWith(args[i], '--')) stop('Invalid option: ', args[i])
  opts[[key]] <- args[i+1]
}
for (required in c('input', 'bim', 'out')) if (is.null(opts[[required]])) {
  stop('Missing --', required)
}
chr <- if (is.null(opts$chr)) '17' else as.character(opts$chr)
locus_win <- if (is.null(opts[['locus-win']])) 100000 else as.numeric(opts[['locus-win']])
minp <- if (is.null(opts[['minp-input']])) 1.0 else as.numeric(opts[['minp-input']])
if (!is.finite(locus_win) || locus_win < 0 || !is.finite(minp) || minp <= 0) stop('Invalid numeric options')
if (!file.exists(opts$input) || !file.exists(opts$bim)) stop('Input file or BIM does not exist.')
dir.create(opts$out, showWarnings=FALSE, recursive=TRUE)
warns <- character()
warning_note <- function(s) { warns <<- c(warns, s); message('WARNING: ', s) }
write_tsv <- function(x, name) write.table(x, file=file.path(opts$out,name), sep='\t', quote=FALSE, row.names=FALSE, na='NA')

b <- read.table(opts$bim, header=FALSE, stringsAsFactors=FALSE, comment.char='', quote='', fill=FALSE)
if (ncol(b) != 6) stop('A PLINK BIM must contain precisely 6 columns.')
names(b) <- c('CHR', 'SNP', 'CM', 'BP', 'A1', 'A2')
b$CHR <- as.character(b$CHR)
b$SNP <- as.character(b$SNP)
b$BP <- suppressWarnings(as.numeric(b$BP))
if (anyNA(b$BP)) stop('Unusable BP positions in BIM.')
if (!all(b$CHR %in% c(chr, paste0('chr',chr)))) stop('BIM contains unexpected chromosomes.')
if (anyDuplicated(b$SNP)) warning_note(paste(sum(duplicated(b$SNP)), 'duplicate SNP identifiers in BIM; match() will use first occurrence.'))
if (is.unsorted(b$BP)) warning_note('BIM BP positions are NOT monotonically sorted; the stock FUSION run-length grouping assumes positional order.')
if (min(b$BP) <= 0) warning_note('BIM has non-positive physical positions.')

w <- read.table(opts$input, header=TRUE, stringsAsFactors=FALSE, check.names=FALSE, comment.char='', quote='')
needed <- c('CHR','P0','P1','FILE','ID','TWAS.P')
if (!all(needed %in% names(w))) stop('Input TWAS file lacks required columns: ', paste(setdiff(needed,names(w)),collapse=', '))
w$TWAS.P <- suppressWarnings(as.numeric(w$TWAS.P))
w$P0 <- suppressWarnings(as.numeric(w$P0))
w$P1 <- suppressWarnings(as.numeric(w$P1))
w <- w[as.character(w$CHR) %in% c(chr,paste0('chr',chr)) & !is.na(w$TWAS.P) & w$TWAS.P < minp, , drop=FALSE]
if (!nrow(w)) stop('No models pass FUSION post-process CHR/TWAS.P filter.')
if (anyNA(w$P0) || anyNA(w$P1)) stop('Missing/non-numeric P0/P1 in model list.')
if (any(w$P0 > w$P1)) warning_note('Some model rows have P0 > P1; original FUSION uses P0 < group_end & P1 > group_start directly.')
if (anyDuplicated(w$FILE)) warning_note('Repeated FILE paths in input model list.')

# Load ORIGINAL prediction-weight SNP rsIDs; reproduce FUSION's genos.keep vector.
ref_ids <- b$SNP
genos_keep <- rep(FALSE, nrow(b))
mod_counts <- data.frame(model_row=seq_len(nrow(w)),FILE=w$FILE,ID=w$ID,
                         n_weight_snps=NA_integer_,n_matched_ref_snps=NA_integer_,
                         n_ambiguous_palindromic=NA_integer_,n_allele_discordant=NA_integer_,
                         stringsAsFactors=FALSE)
comp <- function(x) chartr('ACGT', 'TGCA', toupper(x))
for (i in seq_len(nrow(w))) {
  f <- w$FILE[i]
  if (!file.exists(f)) stop('Missing model file; set working directory to original FUSION execution directory: ',f)
  env <- new.env(parent=baseenv())
  loaded <- tryCatch(load(f, envir=env), error=function(e) stop('Failed loading ',f, ': ',conditionMessage(e)))
  if (!'snps' %in% loaded || ncol(env$snps) < 6) stop('Model file lacks expected snps (>=6 columns): ', f)
  s <- env$snps
  m <- match(as.character(s[,2]), ref_ids)
  keep <- !is.na(m)
  matched <- m[keep]
  genos_keep[matched] <- TRUE
  mod_counts$n_weight_snps[i] <- nrow(s)
  mod_counts$n_matched_ref_snps[i] <- sum(keep)
  if (sum(keep)) {
    wa1 <- toupper(as.character(s[keep,5])); wa2 <- toupper(as.character(s[keep,6]))
    ba1 <- toupper(as.character(b$A1[matched])); ba2 <- toupper(as.character(b$A2[matched]))
    palindrome <- (wa1 == 'A' & wa2 == 'T') | (wa1 == 'T' & wa2 == 'A') | (wa1 == 'G' & wa2 == 'C') | (wa1 == 'C' & wa2 == 'G')
    same <- (wa1 == ba1 & wa2 == ba2) | (wa1 == ba2 & wa2 == ba1)
    strand <- (comp(wa1) == ba1 & comp(wa2) == ba2) | (comp(wa1) == ba2 & comp(wa2) == ba1)
    mod_counts$n_ambiguous_palindromic[i] <- sum(palindrome,na.rm=TRUE)
    mod_counts$n_allele_discordant[i] <- sum(!(same | strand),na.rm=TRUE)
  } else {
    mod_counts$n_ambiguous_palindromic[i] <- 0L
    mod_counts$n_allele_discordant[i] <- 0L
    warning_note(paste('Model has zero LD-reference SNP overlap:',f))
  }
  if (i %% 100L == 0L) message('Loaded ', i, ' / ', nrow(w), ' model SNP lists')
}
write_tsv(mod_counts, 'model_snp_overlap.tsv')
if (any(mod_counts$n_allele_discordant > 0)) warning_note('Model/reference allele discordances detected; review source, ambiguous SNPs, and original QC.')
if (!any(genos_keep)) stop('No matched reference SNPs; cannot reconstruct groups.')

# Reproduce consecutive matched-SNP blocks in BIM row order and FUSION 100-kb buffering.
prev <- c(FALSE, head(genos_keep, -1))
next_ <- c(tail(genos_keep, -1), FALSE)
starts_idx <- which(genos_keep & !prev)
ends_idx <- which(genos_keep & !next_)
stopifnot(length(starts_idx) == length(ends_idx))
raw_start <- b$BP[starts_idx] - locus_win
raw_end <- b$BP[ends_idx] + locus_win
raw <- data.frame(block=seq_along(starts_idx),first_bim_row=starts_idx,last_bim_row=ends_idx,
                  first_matched_snp_pos=b$BP[starts_idx],last_matched_snp_pos=b$BP[ends_idx],
                  buffered_start=raw_start,buffered_end=raw_end)
write_tsv(raw,'preconsolidation_blocks.tsv')

# Same strict 'start < previous_end' consolidation as official post_process.R
c_start <- raw_start[1]; c_end <- raw_end[1]
if (length(raw_start) > 1) for (i in 2:length(raw_start)) {
  n <- length(c_start)
  if (raw_start[i] < c_end[n]) c_end[n] <- max(c_end[n],raw_end[i])
  else { c_start <- c(c_start,raw_start[i]); c_end <- c(c_end,raw_end[i]) }
}

membership <- data.frame()
groups <- data.frame()
for (i in seq_along(c_start)) {
  # IMPORTANT: reproduce P0/P1 overlap selection; do not confuse wgt count with number of loci.
  included <- w$P0 < c_end[i] & w$P1 > c_start[i]
  current <- w[included,,drop=FALSE]
  if (nrow(current)) {
    current$group <- i
    current <- current[,c('group',setdiff(names(current),'group')),drop=FALSE]
    membership <- rbind(membership,current)
  }
  g <- data.frame(group=i,CHR=chr,group_start=c_start[i],group_end=c_end[i],
                  n_models=nrow(current),n_distinct_model_IDs=length(unique(current$ID)),
                  n_reference_snps_inside=sum(b$BP > c_start[i] & b$BP < c_end[i]),
                  n_matched_reference_snps_inside=sum(genos_keep & b$BP > c_start[i] & b$BP < c_end[i]))
  groups <- rbind(groups,g)
}
write_tsv(groups,'regional_groups.tsv')
write_tsv(membership,'regional_model_membership.tsv')

build_status <- 'NOT VERIFIED: a BIM filename or coordinate range cannot independently prove GRCh38.'
if (!is.null(opts[['grch38-map']])) {
  mp <- read.table(opts[['grch38-map']],header=TRUE,stringsAsFactors=FALSE,check.names=FALSE)
  if (!all(c('SNP','CHR','BP') %in% names(mp))) stop('--grch38-map requires columns SNP, CHR, BP.')
  mp <- mp[as.character(mp$CHR) %in% c(chr,paste0('chr',chr)),c('SNP','BP'),drop=FALSE]
  if (anyDuplicated(mp$SNP)) warning_note('GRCh38 map contains duplicate SNP IDs; comparison not uniquely interpretable for these variants.')
  mm <- match(b$SNP, mp$SNP)
  compare <- data.frame(SNP=b$SNP,BIM_BP=b$BP,GRCh38_map_BP=mp$BP[mm],
                        status=ifelse(is.na(mm),'NO_INDEPENDENT_MAP',ifelse(b$BP == mp$BP[mm],'MATCH','MISMATCH')))
  write_tsv(compare,'grch38_position_comparison.tsv')
  build_status <- paste('Compared against user-supplied reference:',sum(compare$status=='MATCH'),'matching;',
                        sum(compare$status=='MISMATCH'),'mismatching;',sum(compare$status=='NO_INDEPENDENT_MAP'),'not in map. Check mapping source/build provenance.')
  if (any(compare$status=='MISMATCH')) warning_note('Discrepant positions versus supplied GRCh38 mapping; do not claim coordinate compatibility until reconciled.')
}

summary <- data.frame(metric=c('analysis_input','ld_bim','input_models_after_filter','unique_model_IDs',
                               'BIM_variants','BIM_unique_rsid','BIM_min_BP','BIM_max_BP',
                               'matched_BIM_variants','preconsolidation_blocks','consolidated_groups','locus_win_bp',
                               'minp_input','default_or_user_z_threshold','reference_build_status'),
                      value=c(normalizePath(opts$input),normalizePath(opts$bim),nrow(w),length(unique(w$ID)),
                              nrow(b),length(unique(b$SNP)),min(b$BP),max(b$BP),sum(genos_keep),
                              length(raw_start),nrow(groups),locus_win,minp,
                              if(is.null(opts$zthresh)) qnorm(0.05/nrow(w)/2,lower.tail=FALSE) else as.numeric(opts$zthresh),build_status))
write_tsv(summary,'audit_summary.tsv')
writeLines(c('THIS SCRIPT DOES NOT VERIFY GENOME BUILD WITHOUT A TRUSTED EXTERNAL GRCh38 MAPPING,',
             'AND DOES NOT RECALCULATE JOINT/CONDITIONAL STATISTICS OR IDENTIFY RETAINED FEATURES.',
             'Compare regional groups and membership to the ORIGINAL source-version FUSION logs and .loc_*.genes outputs.',
             warns),con=file.path(opts$out,'warnings_and_scope.txt'))
message('Finished read-only independent region grouping audit in ',normalizePath(opts$out))
