# Numerical stability of the all-testable FUSION diagnostics

## Scope and thresholds

All records in `reproducibility/diagnostic_20261016/` were generated during diagnostic reruns on 16 October 2026. They are not the original historical analysis stdout/stderr. This archive was assembled without rerunning scientific analyses. FUSION diagnostics used R 3.6.0. The instrumented source and its changes are included in `reproducibility/source/`; it records the calculations while retaining the original selection rules.

| Analysis | Default absolute Z | Common explicit Z | Global retained (both modes) | Locus-specific selected (both modes) |
| --- | ---: | ---: | ---: | ---: |
| Core primary, 353 models | 3.80528140728608 | 4.058183 | 1 | 1 |
| Extended primary, 358 models | 3.80876112046778 | 4.058183 | 1 | 1 |
| Core all-testable, 559 models | 3.91757172039658 | 4.058183 | 1 | 10 |
| Extended all-testable, 1,011 models | 4.05818311062166 | 4.058183 | 1 | 19 |

Default thresholds depend on the number of input models M (two-sided P < 0.05/M); this is distinct from marginal all-tissue FDR preselection. Fixed runs explicitly used --zthresh 4.058183, not the unrounded highest default value. Default rows omit that option; the effective zthresh=0 is the software's automatic-threshold setting. Actual selection thresholds are recorded in the selection events and summary table. The `Default_two_sided_P_threshold_reference` column is the default P reference even on fixed rows, not a newly calculated exact P for the fixed Z.

## Global selection and the conditional-Z safeguard

All eight global selections retained only MAPT-AS1 / ENSG00000264589.2 / GTExv8.ALL.Brain_Cerebellar_Hemisphere. The global loop flags candidates when conditional_z^2 > marginal_z^2 + max_cz_increase^2 (max_cz_increase=1.96). It then marks them as dropped and sets their conditional Z to zero.

The 559- and 1,011-model diagnostics excluded six and seven distinct candidate gene-tissue models, respectively, during the first global-selection iteration. These are numbers of excluded models, not six/seven separate iterations and not counts of unique genes. The guard TSV has no separate excluded flag: instrumentation writes only candidates satisfying the original guard, immediately before the original drop statements. The native console message lists the same candidate paths, concatenated on one line. Default and common-threshold guard records agree.

## Locus-specific selection and subsequent SNP conditioning

The locus-specific loop does not apply the same conditional-Z increase safeguard. The 559- and 1,011-model runs selected 10 and 19 models during this loop, respectively. These include MAPT-AS1, but they are outputs of numerically unstable selection, not validated independent association signals. The 353/358 primary runs selected MAPT-AS1 alone at both levels without the corresponding negative-variance/computational-NaN instability.

For 559/1,011, there were 260/532 negative conditional-variance evaluation records during locus-specific selection (out of 1,546/7,909 evaluations). These are model-by-iteration calculations, not counts of unique models or genes. Selected conditional Z values included approximately 8,253 (559) and 119,159 (1,011), documenting instability during feature selection, not merely after selection. Such values are diagnostic artefacts, not inferential evidence.

Subsequent SNP conditioning yielded 502/1,151 computational NaN Z values. Separately, 20/60 values were NA due to missing GWAS input coverage. Inf counts were zero. For 353/358, computational NaN counts were zero, with 20/38 input-related NA. Do not classify all nonfinite values as computational NaN or replace missing values with zero. SNP_nonfinite_classification.tsv transcribes the existing audit classification; packaging did not recalculate SNP effects.

The instrumented `sqrt(as.numeric(v))` warnings arise from extra diagnostic variance logging. They must not be described as warnings from the unchanged original regional selection loop. Warnings involving the original SNP-conditioning square-root expression arise in that subsequent native calculation. The negative variance values and selection events themselves record the original arithmetic. The common threshold preserved the global and locus-specific retained sets, but did not remove the instability. Therefore, all-testable analyses provide limited evidence about global retention and do not validate a stable full regional joint model.

## Included evidence and file roles

- [Eight-run threshold and stability summary](reproducibility/evidence/Major2_threshold_stability_summary.tsv): thresholds, retained identities/counts, guard counts, negative variances and nonfinite statistics.
- [Stage-specific diagnostics](reproducibility/evidence/selection_stage_diagnostics.tsv): global versus locus-specific variance evaluations.
- [SNP nonfinite classification](reproducibility/evidence/SNP_nonfinite_classification.tsv): computational NaN versus input NA.
- [Regional selected-model identities](reproducibility/evidence/regional_retained_models.tsv): all eight runs, with FILE/ID identifiers; this is a small selection subset, not the separate full 2,281-record membership data.
- `reproducibility/diagnostic_20261016/default_core_559/`, `fixed_core_559/`, `default_extended_1011/` and `fixed_extended_1011/` each contain execution.log, run.selection_events.tsv, run.global_instability_guard.tsv and run.joint_included.dat. The default directories also retain the existing short regional boundaries.
- [Effective parameters for all eight runs](reproducibility/Diagnostic_parameters_20261016.tsv) and [commands](reproducibility/Commands_and_parameters_EN.md) are reused rather than duplicated. The two default primary execution logs/session records and four short default boundaries are retained from the coordinate archive.
- [Instrumented source](reproducibility/source/FUSION.post_process.instrumented.R) and [code differences](reproducibility/source/instrumentation.diff) identify how the diagnostic records were produced. Full variance-by-iteration and matrix intermediate files are not included; existing summaries supply their recorded counts.

Published files are anonymized copies. <FUSION_PROJECT> and <WORKSPACE> replace personal path roots while retaining model filenames, relative directories, order and values. Their checksums describe the public copies, not the private originals. No matched-tissue validation, new model selection or numerical correction is claimed by this packaging step.
