# Column descriptions for the separately supplied model-membership data

This dictionary describes the separately supplied Supplementary_Data_FUSION_model_membership.tsv, which is not included in this archive. All 2,281 source records in that companion file are retained (353, 358, 559 and 1,011 by Analysis_ID); records shared across analyses have not been deduplicated. Values and existing selection flags were transcribed, not recomputed. Personal path roots were anonymized.

| Column | Description |
| --- | --- |
| Analysis_ID | Existing analysis identifier: core_353 or extended_358 (FDR-selected primary/boundary analysis), core_559 or extended_1011 (all-testable sensitivity). |
| Regional_group_ID | Existing FUSION regional group identifier within the analysis; not a gene or model count. |
| Panel | Original prediction-weight panel identifier; includes the tissue. |
| Weight_file | Original weight-file identifier with the personal project root replaced by <FUSION_PROJECT>. Weight files are external inputs and are not included. |
| Feature_ID | Versioned Ensembl feature identifier used by the prediction model. |
| Chromosome | Chromosome in the model list. |
| Model_P0_GRCh38 | Original zero-based model TSS-interval start; for these models P0 = GENCODE TSS - 1. |
| Model_P1_GRCh38 | Original model TSS-interval end; for these models P1 = GENCODE TSS. |
| HSQ | Model-level SNP-heritability estimate reported in the input FUSION result. |
| Best_GWAS_SNP | BEST.GWAS.ID copied from the marginal FUSION input. |
| Best_GWAS_Z | BEST.GWAS.Z copied from the marginal FUSION input. |
| Top_eQTL_SNP | EQTL.ID copied from the marginal FUSION input. |
| Top_eQTL_R2 | EQTL.R2 copied from the marginal FUSION input. |
| Top_eQTL_Z | EQTL.Z copied from the marginal FUSION input. |
| Top_eQTL_GWAS_Z | EQTL.GWAS.Z copied from the marginal FUSION input. |
| NSNP | SNP count aligned to the LD reference in the marginal FUSION association analysis. |
| NWGT | Number of SNPs with nonzero weights in the selected marginal prediction model. |
| Prediction_model | Selected prediction-model label copied from MODEL. |
| Model_CV_R2 | Prediction-model cross-validation R-squared reported in MODELCV.R2. |
| Model_CV_P | Prediction-model cross-validation P value reported in MODELCV.PV. |
| Marginal_TWAS_Z | TWAS.Z in the supplied regional input; not a conditional or joint Z statistic. |
| Marginal_TWAS_P | TWAS.P in the supplied regional input; not a conditional or joint P value. |
| Gene_symbol | Gene label already attached in the audited membership file. |
| Annotation_chromosome | Chromosome in the GENCODE v26 GRCh38 annotation. |
| GENCODE_gene_start | One-based gene start in the GENCODE annotation, not the model P0. |
| GENCODE_gene_end | One-based gene end in the GENCODE annotation, not the model P1. |
| Gene_strand | Gene strand in GENCODE. |
| GENCODE_TSS | One-based transcription start site in GENCODE. |
| Global_retained | Existing True/False flag from the historical global joint_included result. Global selection precedes regional grouping. |
| Global_retention_source | Anonymized identifier of the original global joint-output file supporting Global_retained. |
| Regional_retained_diagnostic | Existing True/False flag recorded during the 2026-10-16 default-threshold regional diagnostic. For the 559/1011 analyses this flag is an unstable algorithmic selection result, not a validated independent signal. |
| Regional_retention_source | Identifier of the archived 2026-10-16 diagnostic source table. The diagnostic_20261016 prefix denotes the archived diagnostic collection; all detailed sensitivity tables are not included in this Major 1 package. |

The all-testable analyses have different global and regional retained sets. Regional flags for 559/1,011 models must not be interpreted as reliable independent genetic signals. The distinction is also stated in Supplementary Table S9C. NA denotes an unavailable source value; no missing statistic was replaced by zero.
