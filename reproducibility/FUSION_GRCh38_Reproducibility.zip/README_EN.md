# FUSION GRCh38 reproducibility archive

This archive contains the commands, code, coordinate evidence and selected diagnostic records supporting the FUSION regional reproducibility checks. The complete Supplementary Tables workbook and the 2,281-row model-membership TSV are supplied as separate companion attachments and are intentionally excluded from this ZIP to avoid duplicate submissions.

## Contents

- reproducibility/: adapted historical and diagnostic commands, effective parameters, local and diagnostic source copies with differences and license, selected reference-processing logs, coordinate evidence, primary diagnostic logs, and four short regional-boundary outputs.
- Supplementary_Data_column_descriptions_EN.md: the column dictionary for the separately supplied model-membership TSV; the TSV itself is not included here.
- SHA256_manifest.tsv: file sizes and SHA256 checksums for this archive's contents, excluding the manifest itself.

The regional summary belongs to Supplementary Table S9C in the separate Supplementary Tables workbook. The complete model-membership data are a separate Supplementary Data attachment. The final Supplementary Data file number has not been assigned here. Neither the workbook nor the model-membership data were edited when this archive was reorganized.

Global retention and the 2026-10-16 regional diagnostic retention flags remain distinct. In the 559/1,011-model analyses, regional flags reflect numerically unstable selections and must not be described as reliable independent signals.

## Current companion-file identifiers (not bundled)

The following existing companion copies are identified for author review. They are supplied separately, not in this ZIP; authors must synchronize them with their final submission versions.

| Current companion filename | File size (bytes) | SHA256 |
| --- | --- | --- |
| Supplementary_Tables_ASD_TWAS_Major2_updated.xlsx | 243282 | 8c1336758d6d8055df7db7a2fa394b73df741893439178aa1cf745c848d5070d |
| Supplementary_Data_FUSION_model_membership.tsv | 1098230 | a2d782898100e701850691964c1e5a7c93ad6ecfc2d91159d2ce3ad6d52577b9 |

## Evidence and provenance

The evidence folder contains the 32,169-variant independent GRCh38 comparison, the full 2,281-record model-coordinate check, GWAS/reference matching statuses, the four-analysis QC and regional-group tables, and the archived original-versus-diagnostic output comparison. The GWAS matching table is a field subset of the existing audited reference-matching output; it contains no GWAS Z or N statistics. There are 26,367 matched reference variants and 5,802 missing from the GWAS input; missing results were not assigned zero.

Coordinate reference: chr17_hg38_rs_noannot.pvar.zst, linked from the [official PLINK resources](https://www.cog-genomics.org/plink/2.0/resources), independently downloaded on 2026-10-16. Its archived compressed SHA256 is `60eb7b9b85a78c2357bd23303cb2357819e677aa82cc4be7d463cdc32e28ad4d`. The complete reference download is not bundled because the per-variant comparison and external reference identifier are supplied. Model annotation: GENCODE v26 GRCh38, the GTEx v8 annotation build; source reference https://storage.googleapis.com/gtex_analysis_v8/reference/gencode.v26.GRCh38.genes.gtf .

The reference-processing logs are existing PLINK records. FUSION console logs under diagnostic_20261016 are anonymized copies generated during the 2026-10-16 audit, not September original-run logs. Original_vs_diagnostic_outputs.tsv records comparisons made on the original files before publication path anonymization. Archived_regional_checks.tsv transcribes already completed boundary/membership checks; packaging did not rerun them.

## Inputs, paths and limitations

<FUSION_PROJECT> is an anonymized input-project root; <WORKSPACE> is an anonymized study workspace. These are placeholders, not literal runnable filesystem paths. Published command blocks are adapted transcriptions/templates, not unmodified historical records. External input and weight identifiers provide filenames, sizes and SHA256 values; the complete GWAS, LD genotypes and prediction weights are not included. Re-execution requires obtaining and configuring these external inputs and the recorded dependencies.

The 1,011-model historical launch header is incomplete, independent complete historical FUSION stdout/stderr was not recovered, and the historical Git commit is not uniquely known. `reproducibility/Source_code_and_versions_EN.md` identifies the supplied current local and diagnostic code by checksum. R 3.6.0 applies to FUSION diagnostic runs; R 4.4.1 applies only to the independent regional helper. Selected all-testable stability diagnostics are included here, as described below; large variance/matrix intermediates remain in the internal audit. This archive is a candidate reproducibility attachment, not a statement that the authors have reviewed or formally submitted it. The separate workbook and Supplementary Data attachment must be handled independently at submission.

## Major Comment 2: numerical-stability evidence

The actual default absolute Z thresholds for 353/358/559/1,011 models were 3.80528140728608, 3.80876112046778, 3.91757172039658 and 4.05818311062166. A common explicit threshold of 4.058183 preserved the observed retained sets but did not remove instability. All eight global selections retained the cerebellar-hemisphere MAPT-AS1 model. Locus-specific selection retained one model for 353/358 but selected 10/19 in the unstable 559/1,011 runs. These latter counts do not establish independent signals. Instability affected locus-specific feature selection and subsequent SNP conditioning.

See [numerical-stability notes](Major2_numerical_stability_notes_EN.md), the [eight-run summary](reproducibility/evidence/Major2_threshold_stability_summary.tsv), [stage diagnostics](reproducibility/evidence/selection_stage_diagnostics.tsv), [SNP classification](reproducibility/evidence/SNP_nonfinite_classification.tsv), and [selected model identities](reproducibility/evidence/regional_retained_models.tsv). The notes explain the six/seven guard-excluded candidates, 10/19 locus-specific selections, 260/532 negative variance evaluation records, and 502/1,151 computational SNP NaN, separately from missing-input NA.

The four all-testable default/fixed directories under `reproducibility/diagnostic_20261016/` include execution logs, ordered selection events, global guard records and global included-model outputs. All of these are **diagnostic reruns generated on 16 October 2026**, not original historical execution logs. Full commands/options and the corresponding instrumented code were already supplied and are retained. No scientific analyses were rerun to assemble this archive.
